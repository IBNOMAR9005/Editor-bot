#!/usr/bin/env python3
"""تجهيز البيئة (idempotent): apt + pip + yt-dlp + فحص GPU/NVENC الحقيقي + تقرير صحة (health.json)."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = Path(os.environ.get("TGBOT_WORK", "/content/tgwork"))
APT = ["ffmpeg", "ghostscript", "qpdf", "libimage-exiftool-perl", "tesseract-ocr", "tesseract-ocr-ara",
       "tesseract-ocr-eng", "fontconfig", "fonts-noto-core", "fonts-hosny-amiri"]
# LibreOffice و DeepFilterNet بيتثبّتوا lazily أول ما الميزة تتطلب (مراحل 2 و 4)


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def have_pkg(p):
    return sh(["dpkg", "-s", p]).returncode == 0


def apt_install():
    missing = [p for p in APT if not have_pkg(p)]
    if not missing:
        return [], "كل الحزم متثبّتة بالفعل"
    pre = [] if os.geteuid() == 0 else ["sudo"]
    env = dict(os.environ, DEBIAN_FRONTEND="noninteractive")
    sh(pre + ["apt-get", "update", "-qq"], env=env)
    r = sh(pre + ["apt-get", "install", "-y", "-qq", "--no-install-recommends"] + missing, env=env)
    failed = []
    if r.returncode != 0:
        for p in missing:
            if sh(pre + ["apt-get", "install", "-y", "-qq", "--no-install-recommends", p], env=env).returncode != 0:
                failed.append(p)
    sh(["fc-cache", "-f"])
    return failed, f"اتثبّت {len(missing) - len(failed)} حزمة"


def pip_install():
    r = sh([sys.executable, "-m", "pip", "install", "-q", "-r", str(ROOT / "requirements.txt")])
    ok1 = r.returncode == 0
    r2 = sh([sys.executable, "-m", "pip", "install", "-q", "-U", "yt-dlp"])
    v = sh([sys.executable, "-m", "yt_dlp", "--version"]).stdout.strip()
    return ok1, (v if r2.returncode == 0 and v else None)


def first_line(cmd):
    try:
        r = sh(cmd)
        out = (r.stdout or r.stderr).strip().splitlines()
        return out[0] if r.returncode == 0 and out else None
    except FileNotFoundError:
        return None


def gpu_state():
    if not shutil.which("nvidia-smi") or sh(["nvidia-smi", "-L"]).returncode != 0:
        return None, ""
    name = (sh(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"]).stdout.strip().splitlines() or [""])[0]
    t = sh(["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=duration=1:size=320x240:rate=30",
            "-c:v", "h264_nvenc", "-f", "null", "-"])
    return ("nvenc" if t.returncode == 0 else "gpu"), name


def main():
    WORK.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    print("🔧 apt …")
    failed, apt_msg = apt_install()
    print("🐍 pip …")
    pip_ok, ytdlp = pip_install()

    tools = {
        "ffmpeg": first_line(["ffmpeg", "-version"]), "ffprobe": first_line(["ffprobe", "-version"]),
        "gs": first_line(["gs", "--version"]), "qpdf": first_line(["qpdf", "--version"]),
        "exiftool": first_line(["exiftool", "-ver"]), "tesseract": first_line(["tesseract", "--version"]),
    }
    langs = sh(["tesseract", "--list-langs"]).stdout if tools["tesseract"] else ""
    ara = "ara" in langs.split()
    fonts_ar = len([l for l in sh(["fc-list", ":lang=ar", "family"]).stdout.splitlines() if l.strip()])
    gpu, gpu_name = gpu_state()
    try:
        import aiogram, pikepdf  # noqa: F401
        libs_ok = True
    except Exception:
        libs_ok = False

    ubuntu = ""
    try:
        ubuntu = next(l.split("=")[1].strip('"') for l in Path("/etc/os-release").read_text().splitlines() if l.startswith("VERSION_ID"))
    except Exception:
        pass

    health = {
        "ts": time.time(), "python": sys.version.split()[0], "ubuntu": ubuntu,
        "tools": {"ffmpeg": bool(tools["ffmpeg"] and tools["ffprobe"]), "gs": bool(tools["gs"]), "qpdf": bool(tools["qpdf"]),
                  "exiftool": bool(tools["exiftool"]), "tesseract+ara": bool(tools["tesseract"] and ara),
                  "خطوط عربي": fonts_ar > 0, "yt-dlp": bool(ytdlp)},
        "gpu": gpu, "gpu_name": gpu_name, "yt_dlp": ytdlp, "apt_failed": failed, "fonts_ar": fonts_ar,
    }
    (WORK / "health.json").write_text(json.dumps(health, ensure_ascii=False))

    mark = lambda ok: "✅" if ok else "⚠️"  # noqa: E731
    print("\n══════ تقرير الفحص ══════")
    print(f"{mark(libs_ok)} مكتبات بايثون (aiogram, pikepdf)")
    for n, v in tools.items():
        print(f"{mark(v)} {n:10} {v or 'مش موجود'}")
    print(f"{mark(ara)} tesseract عربي (ara)")
    print(f"{mark(fonts_ar)} خطوط عربية: {fonts_ar} (Cairo هيتضاف في مرحلة الـ PDF)")
    print(f"{mark(ytdlp)} yt-dlp {ytdlp or ''}")
    print("⚡ GPU: " + {"nvenc": f"✅ {gpu_name} + NVENC شغّال (اختبار تشفير حقيقي نجح)",
                        "gpu": f"🟡 {gpu_name} موجود بس NVENC مش متاح في ffmpeg ده (هنتعامل معاه في مرحلة الفيديو)",
                        None: "— مفيش GPU (هنشتغل CPU)"}[gpu])
    print(f"ℹ️ {apt_msg} • ⏱ {time.time() - t0:.0f} ث" + (f" • ⚠️ فشل تثبيت: {', '.join(failed)}" if failed else ""))
    critical = health["tools"]["ffmpeg"] and libs_ok and pip_ok
    if not critical:
        print("\n❌ في أداة أساسية ناقصة (ffmpeg أو مكتبات بايثون). راجع الأخطاء فوق وشغّل الخلية تاني.")
        sys.exit(1)
    print("\n✅ البيئة جاهزة")


if __name__ == "__main__":
    main()
