"""اختبار دخاني بدون تليجرام حقيقي: سيشن مزيّف بيسجّل كل استدعاءات الـ API.
تشغيل:  python tests/smoke_test.py"""
from __future__ import annotations

import asyncio
import datetime as dt
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from aiogram import Bot, Dispatcher  # noqa: E402
from aiogram.client.session.base import BaseSession  # noqa: E402
from aiogram.types import CallbackQuery, Chat, Document, File, Message, Update, User  # noqa: E402

from config import Config  # noqa: E402
from core.app import AppCtx, Whitelist  # noqa: E402
from core.cleanup import sweep_once  # noqa: E402
from core.queue import JobQueue  # noqa: E402
from core.state import Dialogs, Store  # noqa: E402
from handlers import fallback, file_router, menu, rename, settings, start  # noqa: E402
from ui import keyboards as K, texts as T  # noqa: E402

OWNER, STRANGER = 111, 999
TOKEN = "123456789:AAEhBP0av28n4G2g7R8t1u2VwXyZ0aBcDeF"
NOW = dt.datetime.now(dt.timezone.utc)


class FakeSession(BaseSession):
    def __init__(self, local_file: Path):
        super().__init__()
        self.calls, self.local_file, self._mid = [], local_file, 1000

    async def close(self):
        pass

    async def stream_content(self, *a, **k):
        yield b""

    async def make_request(self, bot, method, timeout=None):
        name = type(method).__name__
        self.calls.append((name, method))
        rt = getattr(method, "__returning__", bool)
        if name == "GetFile":
            res = File(file_id="F1", file_unique_id="U1", file_size=self.local_file.stat().st_size,
                       file_path=str(self.local_file))
        elif name == "GetMe":
            res = User(id=1, is_bot=True, first_name="bot", username="testbot")
        elif rt is bool:
            res = True
        else:  # أي رسالة (send*/edit*)
            self._mid += 1
            res = Message(message_id=self._mid, date=NOW, chat=Chat(id=OWNER, type="private"), text="x")
        return res

    def sent(self, name):
        return [m for n, m in self.calls if n == name]


def msg(text=None, uid=OWNER, mid=1, **extra):
    return Update(update_id=mid, message=Message(
        message_id=mid, date=NOW, chat=Chat(id=uid, type="private"),
        from_user=User(id=uid, is_bot=False, first_name="Ahmed"), text=text, **extra))


def cb(data, uid=OWNER, mid=50):
    return Update(update_id=mid, callback_query=CallbackQuery(
        id=f"cb{mid}", from_user=User(id=uid, is_bot=False, first_name="Ahmed"), chat_instance="x", data=data,
        message=Message(message_id=mid, date=NOW, chat=Chat(id=OWNER, type="private"), text="card")))


def last_text(sess):
    for n, m in reversed(sess.calls):
        if n in ("EditMessageText", "SendMessage"):
            return m.text
    return ""


async def main():
    tmp = Path(tempfile.mkdtemp(prefix="tgsmoke_"))
    work, home = tmp / "work", tmp / "home"
    env = {"BOT_TOKEN": TOKEN, "API_ID": "1", "API_HASH": "a" * 32, "ALLOWED_USER_IDS": str(OWNER),
           "TGBOT_HOME": str(home), "TGBOT_WORK": str(work)}
    cfg = Config.from_env(env)
    cfg.ensure_dirs()

    # ملف صوت حقيقي في مكان "server-data" (زي ما السيرفر المحلي بيعمل)
    audio = cfg.server_dir / "documents" / "file_1.mp3"
    audio.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=duration=2", str(audio)])
    if r.returncode != 0:
        audio.write_bytes(b"ID3" + b"\0" * 2000)

    sess = FakeSession(audio)
    bot = Bot(TOKEN, session=sess)
    store, runtime = Store(cfg.settings_db), Store(cfg.runtime_db)
    queue = JobQueue(bot, cancel_markup=lambda j: K.job_controls(j.id))
    ctx = AppCtx(cfg=cfg, store=store, runtime=runtime, queue=queue, dialogs=Dialogs(), version="0.1.0")
    dp = Dispatcher(ctx=ctx)
    wl = Whitelist(cfg.allowed)
    dp.message.outer_middleware(wl)
    dp.callback_query.outer_middleware(wl)
    for rt in (start.router, menu.router, settings.router, file_router.router, rename.router, fallback.router):
        dp.include_router(rt)
    worker = asyncio.create_task(queue.worker())
    ok = lambda c, label: print(("✅" if c else "❌"), label) or c  # noqa: E731
    results = []

    # 1) غريب: يتتجاهل، ماعدا /id
    n0 = len(sess.calls)
    await dp.feed_update(bot, msg("/start", uid=STRANGER, mid=1))
    await dp.feed_update(bot, msg(K.M_RENAME, uid=STRANGER, mid=2))
    results.append(ok(len(sess.calls) == n0, "الغريب متتجاهل تمامًا (صفر استدعاءات API)"))
    await dp.feed_update(bot, msg("/id", uid=STRANGER, mid=3))
    results.append(ok(str(STRANGER) in last_text(sess), "/id بيرد للغريب برقمه بس"))

    # 2) /start: لوحة رئيسية بأزرار حقيقية ملونة
    await dp.feed_update(bot, msg("/start", mid=4))
    rm = sess.sent("SendMessage")[-1].reply_markup
    flat = [b for row in rm.keyboard for b in row]
    results.append(ok(isinstance(rm.keyboard, list) and rm.is_persistent and len(flat) == 9 and flat[0].style == "primary",
                      "/start → ReplyKeyboard دايمة (9 أزرار) بألوان style"))

    # 3) زرار إعادة التسمية الرئيسي → intent
    await dp.feed_update(bot, msg(K.M_RENAME, mid=5))
    results.append(ok(ctx.dialogs.intent.get(OWNER) is not None, "زرار ✏️ بيظبط intent للملف الجاي"))

    # 4) ملف يتبعت → تحميل → تحليل → شاشة التسمية على طول (بسبب intent)
    doc = Document(file_id="F1", file_unique_id="U1", file_name="my_cool_song_(1).mp3", mime_type="audio/mpeg",
                   file_size=audio.stat().st_size)
    await dp.feed_update(bot, msg(mid=6, document=doc))
    prompt = last_text(sess)
    results.append(ok("اكتب الاسم الجديد" in prompt, "الملف → شاشة التسمية مباشرة (intent)"))
    rm = [m for n, m in sess.calls if n == "EditMessageText"][-1].reply_markup
    labels = [b.text for row in rm.inline_keyboard for b in row]
    results.append(ok(any("اسم ذكي: my cool song" in l for l in labels), "زرار الاسم الذكي ظاهر: " + labels[0]))
    ref = next(iter(ctx.runtime._exec("SELECT ref FROM sessions").fetchone()))

    # 5) كتابة الاسم → job → إرسال
    await dp.feed_update(bot, msg("محاضرة رقم 1", mid=7))
    for _ in range(100):
        await asyncio.sleep(0.1)
        if queue.running is None and not queue._pending and sess.sent("SendAudio"):
            break
    sa = sess.sent("SendAudio")
    results.append(ok(len(sa) == 1, "اتبعت كـ Audio player"))
    if sa:
        sent_path = sa[0].audio
        results.append(ok(isinstance(sent_path, str) and sent_path.startswith("file://") and sa[0].title == "محاضرة رقم 1",
                          f"إرسال بـ file:// والـ title=الاسم الجديد"))
    results.append(ok("تمت إعادة التسمية" in last_text(sess), "رسالة النجاح ظهرت"))
    results.append(ok(not any(cfg.jobs_dir.iterdir()), "مجلد المهمة اتنضّف بعد الانتهاء (try/finally)"))
    results.append(ok(audio.exists(), "الملف الأصلي لسه موجود (للعمليات التانية على نفس الكارت)"))

    # 6) كارت الملف العادي بدون intent
    await dp.feed_update(bot, msg(mid=8, document=doc))
    card = last_text(sess)
    results.append(ok("ملف صوت" in card and "Sample rate" in card and "جاي لنوع الملف ده" in card, "كارت الصوت: بيانات + 'جاي'"))
    rm = [m for n, m in sess.calls if n == "EditMessageText"][-1].reply_markup
    styles = [b.style for row in rm.inline_keyboard for b in row]
    results.append(ok("primary" in styles and "danger" in styles, f"أزرار inline ملونة: {styles}"))
    ref2 = ctx.runtime._exec("SELECT ref FROM sessions ORDER BY created DESC").fetchone()[0]

    # 7) تفاصيل / رجوع / جلسة منتهية
    await dp.feed_update(bot, cb(f"c:info:{ref2}", mid=60))
    results.append(ok("كل التفاصيل" in last_text(sess), "زرار كل التفاصيل"))
    n = len(sess.sent("AnswerCallbackQuery"))
    await dp.feed_update(bot, cb("c:card:nonexist", mid=61))
    results.append(ok(sess.sent("AnswerCallbackQuery")[-1].show_alert is True, "كارت منتهي → تنبيه واضح"))
    await dp.feed_update(bot, cb(f"c:card:{ref2}", uid=STRANGER, mid=62))
    results.append(ok(len(sess.sent("AnswerCallbackQuery")) == n + 1, "كارت حد تاني من غير صلاحية → متتجاهل"))

    # 8) الإعدادات
    await dp.feed_update(bot, msg(K.M_SETTINGS, mid=9))
    await dp.feed_update(bot, cb("s:tgl:notify_boot", mid=63))
    results.append(ok(store.get_setting(OWNER, "notify_boot") is False, "تبديل إعداد وحفظه"))

    # 9) الحالة والقدرات والإقلاع
    await dp.feed_update(bot, msg(K.M_HELP, mid=10))
    results.append(ok("شغّال دلوقتي" in last_text(sess) and "جاي" in last_text(sess), "❓ القدرات (جاهز/جاي) متولّدة من registry"))
    await dp.feed_update(bot, msg(K.M_STATUS, mid=11))
    results.append(ok("حالة النظام" in last_text(sess), "📊 الحالة"))
    st = T.startup({**ctx.sysinfo(), "boot_kind": "recovered", "gap_seconds": 420, "lost_jobs": ["إعادة تسمية"]})
    results.append(ok("رجعت للشغل" in st and "إعادة تسمية" in st and len(st) < 3500, f"رسالة الإقلاع/التعافي ({len(st)} حرف)"))

    # 10) إلغاء مهمة شغّالة (job بطيء)
    from core.queue import Job
    started = asyncio.Event()

    async def slow(job):
        started.set()
        await asyncio.sleep(30)
    job = Job(user_id=OWNER, chat_id=OWNER, msg_id=70, title="بطيئة", run=slow)
    await queue.submit(job)
    await asyncio.wait_for(started.wait(), 3)
    await dp.feed_update(bot, cb(f"j:cancel:{job.id}", mid=64))
    await asyncio.sleep(0.3)
    results.append(ok(job.state == "cancelled" and queue.running is None, "إلغاء مهمة شغّالة بيوقفها فعلًا"))

    # 11) تنظيف: كارت منتهي يتمسح ملفه
    old = ctx.runtime.new_session(OWNER, {"local": str(cfg.server_dir / "documents" / "old.bin"), "name": "o"})
    (cfg.server_dir / "documents" / "old.bin").write_bytes(b"x" * 10)
    ctx.runtime._exec("UPDATE sessions SET used=? WHERE ref=?", (0, old))
    removed = sweep_once(cfg, runtime)
    results.append(ok(removed >= 1 and not (cfg.server_dir / "documents" / "old.bin").exists(), "تنظيف الكروت المنتهية وملفاتها"))

    worker.cancel()
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"\n{sum(results)}/{len(results)} اختبار نجح")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
