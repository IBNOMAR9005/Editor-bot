"""طابور المهام: مهمة معالجة واحدة في المرة (CPU الـ Colab محدود) + ترتيب الانتظار + إلغاء حقيقي
(بيقتل الـ subprocess) + تنظيف مضمون (try/finally) حتى لو المهمة فشلت."""
from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable

from core.progress import edit_safe

log = logging.getLogger("queue")


class UserError(Exception):
    """خطأ مفهوم للمستخدم: رسالته بتتعرض زي ما هي (من غير traceback)."""


@dataclass
class Job:
    user_id: int
    chat_id: int
    msg_id: int
    title: str
    run: Callable[["Job"], Awaitable[None]]
    id: str = field(default_factory=lambda: secrets.token_urlsafe(5)[:6].replace("-", "x").replace("_", "y"))
    state: str = "queued"          # queued | running | done | failed | cancelled
    created: float = field(default_factory=time.time)
    started: float = 0.0
    cancelled: bool = False
    task: asyncio.Task | None = None
    procs: set = field(default_factory=set)
    cleanups: list = field(default_factory=list)
    last_shown_pos: int = -1

    def add_cleanup(self, fn):
        self.cleanups.append(fn)

    def kill_procs(self):
        for p in list(self.procs):
            try:
                if p.returncode is None:
                    p.kill()
            except ProcessLookupError:
                pass


async def run_cmd(job: Job, *args, timeout: float | None = None):
    """تشغيل أمر خارجي بأمان (exec بمعاملات list، مش shell) وتسجيله في المهمة عشان الإلغاء يقتله."""
    proc = await asyncio.create_subprocess_exec(*map(str, args), stdout=asyncio.subprocess.PIPE,
                                                stderr=asyncio.subprocess.PIPE)
    job.procs.add(proc)
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    finally:
        job.procs.discard(proc)
        if proc.returncode is None:
            proc.kill()
    return proc.returncode, out, err


class JobQueue:
    def __init__(self, bot, cancel_markup: Callable[[Job], object] | None = None):
        self.bot = bot
        self.cancel_markup = cancel_markup
        self._q: asyncio.Queue = asyncio.Queue()
        self._pending: list[Job] = []
        self.running: Job | None = None
        self.jobs: dict[str, Job] = {}
        self.on_change: Callable[[], None] | None = None

    # ---- واجهة ----
    async def submit(self, job: Job) -> int:
        self.jobs[job.id] = job
        self._pending.append(job)
        await self._q.put(job)
        self._changed()
        await self._refresh_positions()
        return self.position(job)

    def position(self, job: Job) -> int:
        """0 = شغّال/هيشتغل دلوقتي، 1+ = ترتيب الانتظار."""
        if job is self.running:
            return 0
        try:
            return self._pending.index(job) + (1 if self.running else 0)
        except ValueError:
            return 0

    def user_jobs(self, uid):
        return [j for j in self.jobs.values() if j.user_id == uid and j.state in ("queued", "running")]

    def cancel(self, job_id: str, uid: int | None = None) -> bool:
        job = self.jobs.get(job_id)
        if not job or (uid is not None and job.user_id != uid) or job.state not in ("queued", "running"):
            return False
        job.cancelled = True
        job.kill_procs()
        if job.task and not job.task.done():
            job.task.cancel()
        if job in self._pending:
            self._pending.remove(job)
        return True

    def snapshot(self) -> dict:
        return {"running": self.running.title if self.running else None, "waiting": len(self._pending)}

    def _changed(self):
        if self.on_change:
            try:
                self.on_change()
            except Exception:
                pass

    async def _refresh_positions(self):
        for j in list(self._pending):
            pos = self.position(j)
            if pos != j.last_shown_pos:
                j.last_shown_pos = pos
                mk = self.cancel_markup(j) if self.cancel_markup else None
                await edit_safe(self.bot, j.chat_id, j.msg_id,
                                f"⏳ <b>{j.title}</b>\nفي الانتظار — ترتيبك رقم <b>{pos}</b>\n"
                                f"<i>مهمة واحدة بتشتغل في المرة عشان الأداء.</i>", mk)

    # ---- العامل ----
    async def worker(self):
        while True:
            job: Job = await self._q.get()
            if job.cancelled or job.state != "queued":
                continue
            if job in self._pending:
                self._pending.remove(job)
            self.running, job.state, job.started = job, "running", time.time()
            self._changed()
            await self._refresh_positions()
            try:
                job.task = asyncio.create_task(job.run(job))
                await job.task
                job.state = "done"
            except asyncio.CancelledError:
                if job.cancelled:
                    job.state = "cancelled"
                    await edit_safe(self.bot, job.chat_id, job.msg_id,
                                    f"🛑 <b>{job.title}</b> — اتلغت.", None)
                else:
                    raise  # إيقاف البوت نفسه
            except UserError as e:
                job.state = "failed"
                await edit_safe(self.bot, job.chat_id, job.msg_id, f"❌ <b>{job.title}</b>\n{e}", None)
            except Exception:
                job.state = "failed"
                log.exception("job %s failed", job.id)
                await edit_safe(self.bot, job.chat_id, job.msg_id,
                                f"❌ <b>{job.title}</b> فشلت بسبب خطأ غير متوقع.\n"
                                f"التفاصيل اتسجلت في اللوج. جرّب تاني، ولو اتكررت ابعتلي اللي حصل.", None)
            finally:
                job.kill_procs()
                for fn in job.cleanups:
                    try:
                        r = fn()
                        if asyncio.iscoroutine(r):
                            await r
                    except Exception:
                        log.exception("cleanup error")
                self.running = None
                self._changed()
                await self._refresh_positions()
                # نخلّي المهام القديمة تتنضف من الذاكرة
                if len(self.jobs) > 200:
                    for k in [k for k, j in self.jobs.items() if j.state not in ("queued", "running")][:100]:
                        self.jobs.pop(k, None)
