"""سجل الوظايف: مصدر الحقيقة الوحيد لـ (إيه جاهز / إيه جاي). الأزرار ونص "القدرات" ورسالة الإقلاع
كلها بتتولّد منه، فمفيش زرار بيظهر لوظيفة مش شغّالة ولا وعد مش حقيقي.
لما تخلّص مرحلة: غيّر ready=True للوظايف اللي اتنفّذت."""
from __future__ import annotations

from dataclasses import dataclass

VERSION_PHASE_DONE = 1

PHASES = {1: "الأساس", 2: "الصوت", 3: "الفيديو", 4: "الـ PDF", 5: "التحميل من روابط",
          6: "الـ Metadata", 7: "لمسات ذكية"}

# الألوان: primary=أزرق (الأساسي/المقترح)، success=أخضر (ابدأ/تأكيد)، danger=أحمر (إلغاء/حذف)
KINDS_LABEL = {
    "audio": "🎵 ملف صوت", "video": "🎬 فيديو", "pdf": "📄 ملف PDF",
    "image": "🖼 صورة", "office": "📝 ملف أوفيس", "other": "📎 ملف",
}
ALL = ("audio", "video", "pdf", "image", "office", "other")


@dataclass(frozen=True)
class Action:
    key: str
    label: str
    kinds: tuple
    section: str      # general | audio | video | pdf | convert | link | meta
    phase: int
    ready: bool = False
    style: str = ""   # "" | primary | success | danger
    blurb: str = ""


ACTIONS = [
    # ---- عام ----
    Action("rename", "✏️ إعادة تسمية", ALL, "general", 1, True, "primary", "أي ملف، بنفس الامتداد، من غير ما تنزّله وترفعه تاني"),
    Action("info", "📋 كل التفاصيل", ALL, "general", 1, True, "", "الحجم والكودك والـ bitrate والمدة والأبعاد وعدد الصفحات…"),
    Action("meta", "🏷️ Metadata", ALL, "meta", 6, False, "success", "عرض وتعديل وحذف بيانات الملف (قديم وجديد جنب بعض)"),
    # ---- صوت ----
    Action("a_convert", "🔁 تحويل الصيغة", ("audio",), "audio", 2, False, "primary", "mp3 / m4a / opus / ogg / wav / flac + bitrate وقنوات"),
    Action("a_cut", "✂️ قص جزء", ("audio",), "audio", 2, False, "", "من mm:ss لـ mm:ss"),
    Action("a_split", "🔪 تقسيم لأجزاء", ("audio",), "audio", 2, False, "", "N أجزاء أو نقاط زمنية — اسم (part1)، (part2)…"),
    Action("a_merge", "🧩 دمج ريكوردات", ("audio",), "audio", 2, False, "", "رتّبهم وأنا أدمجهم"),
    Action("a_denoise", "🎙 تنقية الصوت", ("audio",), "audio", 2, False, "", "FFmpeg سريع أو AI (DeepFilterNet)"),
    # ---- فيديو ----
    Action("v_compress", "🗜 ضغط الفيديو", ("video",), "video", 3, False, "primary", "دقة/كودك/CRF — مع GPU لو متاح"),
    Action("v_cut", "✂️ قص جزء", ("video",), "video", 3, False, "", "سريع بدون ترميز أو دقيق"),
    Action("v_merge", "🧩 دمج فيديوهات", ("video",), "video", 3, False, "", "بدون إعادة ترميز لو متطابقين"),
    Action("v_extract", "🎧 فصل الصوت", ("video",), "video", 3, False, "", "نسخ مباشر أو تحويل"),
    Action("v_container", "📦 تغيير الصيغة", ("video",), "video", 3, False, "", "mp4 / mkv / webm / mov"),
    # ---- PDF ----
    Action("p_compress", "🗜 ضغط", ("pdf",), "pdf", 4, False, "primary", "Ghostscript مع تقدير الحجم"),
    Action("p_pages", "📑 استخراج صفحات", ("pdf",), "pdf", 4, False, "", "5-12 أو 1-3,7,10-12"),
    Action("p_ocr", "🔍 OCR عربي/إنجليزي", ("pdf",), "pdf", 4, False, "", "كشف تلقائي للممسوح ضوئيًا"),
    Action("p_merge", "🧩 دمج", ("pdf", "office"), "pdf", 4, False, "", "PDF و Word مع بعض"),
    Action("p_split", "✂️ تقسيم", ("pdf",), "pdf", 4, False, "", "كل N صفحات"),
    Action("p_toimg", "🖼 PDF ← صور", ("pdf",), "pdf", 4, False, "", "كل صفحة صورة بدقة تختارها"),
    Action("p_extract_img", "📤 استخراج الصور", ("pdf",), "pdf", 4, False, "", "تتبعت zip"),
    Action("p_tools", "🛠 تدوير/حذف/علامة مائية/حماية", ("pdf",), "pdf", 4, False, "", ""),
    Action("o_topdf", "📄 تحويل لـ PDF", ("office",), "convert", 4, False, "primary", "Word / PowerPoint بخطوط عربي سليمة"),
    Action("i_topdf", "📄 صور ← PDF", ("image",), "convert", 4, False, "primary", "رتّب الصور واختار المقاس والجودة"),
    # ---- روابط ----
    Action("dl", "⬇️ تحميل من رابط", (), "link", 5, False, "success", "yt-dlp — صوت أو فيديو بالصيغة اللي تختارها"),
]

SECTIONS = {
    "general": "✨ لأي ملف",
    "audio": "🎵 الصوت",
    "video": "🎬 الفيديو",
    "pdf": "📄 الـ PDF",
    "convert": "🔄 تحويلات",
    "link": "⬇️ التحميل من الروابط",
    "meta": "🏷️ Metadata",
}


def get(key: str) -> Action:
    return next(a for a in ACTIONS if a.key == key)


def is_ready(key: str) -> bool:
    return get(key).ready


def for_kind(kind: str, ready: bool = True):
    return [a for a in ACTIONS if kind in a.kinds and a.ready == ready]


def for_section(section: str):
    return [a for a in ACTIONS if a.section == section]


def ready_actions():
    return [a for a in ACTIONS if a.ready]


def upcoming_actions():
    return [a for a in ACTIONS if not a.ready]
