"""شريط التقدم والتحديث الآمن للرسايل (throttled عشان flood limits)."""
from __future__ import annotations

import asyncio
import logging
import os
import time
from contextlib import asynccontextmanager

from aiogram.exceptions import TelegramBadRequest, TelegramRetryAfter

from core.utils import human_elapsed, human_size

log = logging.getLogger("progress")


def bar(pct: float, width: int = 12) -> str:
    pct = max(0.0, min(100.0, pct))
    full = int(round(width * pct / 100))
    return "▰" * full + "▱" * (width - full) + f" {pct:.0f}%"


async def edit_safe(bot, chat_id, msg_id, text, markup=None) -> bool:
    """تعديل رسالة من غير ما نقع في 'message is not modified' أو flood."""
    try:
        await bot.edit_message_text(text, chat_id=chat_id, message_id=msg_id, reply_markup=markup,
                                    disable_web_page_preview=True)
        return True
    except TelegramRetryAfter as e:
        log.warning("flood: retry after %ss — skipping this update", e.retry_after)
        return False
    except TelegramBadRequest as e:
        if "not modified" in str(e).lower():
            return True
        log.info("edit failed: %s", str(e)[:100])
        return False
    except Exception as e:  # الشبكة/السيرفر
        log.info("edit error: %s", type(e).__name__)
        return False


class Reporter:
    """بيحدّث رسالة واحدة (مش بيبعت رسايل جديدة) كل min_interval ثانية على الأكتر."""

    def __init__(self, bot, chat_id, msg_id, markup=None, min_interval: float = 3.5):
        self.bot, self.chat_id, self.msg_id = bot, chat_id, msg_id
        self.markup, self.min_interval = markup, min_interval
        self._last = 0.0

    async def update(self, text, markup="__keep__", force: bool = False) -> bool:
        now = time.monotonic()
        if not force and now - self._last < self.min_interval:
            return False
        self._last = now
        mk = self.markup if markup == "__keep__" else markup
        return await edit_safe(self.bot, self.chat_id, self.msg_id, text, mk)


def newest_file_size(dirs, since: float, max_depth: int = 4) -> int:
    """أكبر حجم لملف اتعدّل بعد `since` جوه الـ dirs. بنستخدمه كمؤشر تقريبي لتقدم التحميل من تليجرام
    (السيرفر المحلي مبيدّيش progress حقيقي)."""
    best = 0

    def walk(p, depth):
        nonlocal best
        try:
            with os.scandir(p) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            if depth < max_depth:
                                walk(e.path, depth + 1)
                        else:
                            st = e.stat(follow_symlinks=False)
                            if st.st_mtime >= since and st.st_size > best:
                                best = st.st_size
                    except OSError:
                        continue
        except OSError:
            return

    for d in dirs:
        walk(str(d), 0)
    return best


@asynccontextmanager
async def ticker(reporter: Reporter, render, interval: float = 4.0):
    """بيشغّل مهمة خلفية بتستدعي render(elapsed) وتحدّث الرسالة طول ما الـ block شغال
    (للعمليات الطويلة اللي مفيهاش progress حقيقي: تحميل من تليجرام / رفع)."""
    t0 = time.monotonic()
    stop = asyncio.Event()

    async def loop():
        while not stop.is_set():
            try:
                text = render(time.monotonic() - t0)
                if asyncio.iscoroutine(text):
                    text = await text
                await reporter.update(text, force=True)
            except Exception as e:
                log.debug("ticker render error: %s", e)
            try:
                await asyncio.wait_for(stop.wait(), timeout=interval)
            except asyncio.TimeoutError:
                pass

    task = asyncio.create_task(loop())
    try:
        yield
    finally:
        stop.set()
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass


def download_render(expected: int, dirs, started_wall: float, title: str):
    """رسالة 'جاري التحميل من تليجرام' مع عدّاد وقت وتقدير حجم لو قدرنا نراقب الديسك."""

    async def render(elapsed):
        seen = await asyncio.to_thread(newest_file_size, dirs, started_wall - 5)
        txt = f"⏳ <b>{title}</b>\nجاري التحميل من تليجرام للسيرفر…\n⏱ {human_elapsed(elapsed)}"
        if expected and seen > 1024 * 1024:
            pct = min(99.0, seen * 100 / expected)
            txt += f"\n{bar(pct)}\n📥 {human_size(seen)} / {human_size(expected)} <i>(تقريبي)</i>"
        elif expected:
            txt += f"\n📦 الحجم: {human_size(expected)}"
        return txt

    return render
