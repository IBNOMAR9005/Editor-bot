"""بيانات الملف: ffprobe للصوت/الفيديو/الصور، pikepdf للـ PDF. كله بدون shell (exec بمعاملات list)."""
from __future__ import annotations

import asyncio
import json
import mimetypes
from pathlib import Path

from core.utils import human_bitrate, human_duration, human_size, split_ext

AUDIO_EXT = {".mp3", ".m4a", ".aac", ".ogg", ".oga", ".opus", ".wav", ".flac", ".wma", ".amr", ".aiff", ".mka"}
VIDEO_EXT = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".flv", ".wmv", ".m4v", ".3gp", ".ts", ".mpg", ".mpeg"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tiff", ".tif", ".heic"}
OFFICE_EXT = {".doc", ".docx", ".ppt", ".pptx", ".odt", ".odp", ".rtf", ".xls", ".xlsx"}


def detect_kind(name: str, mime: str | None = None) -> str:
    _s, ext = split_ext(name or "")
    ext = ext.lower()
    mime = (mime or mimetypes.guess_type(name or "")[0] or "").lower()
    if ext == ".pdf" or mime == "application/pdf":
        return "pdf"
    if ext in AUDIO_EXT or mime.startswith("audio/"):
        return "audio"
    if ext in VIDEO_EXT or mime.startswith("video/"):
        return "video"
    if ext in IMAGE_EXT or mime.startswith("image/"):
        return "image"
    if ext in OFFICE_EXT:
        return "office"
    return "other"


def _fps(rate: str):
    try:
        a, b = rate.split("/")
        v = float(a) / float(b)
        return round(v, 2) if v else None
    except Exception:
        return None


def _res_label(h):
    if not h:
        return ""
    for lim, lab in ((4320, "8K"), (2160, "4K"), (1440, "2K"), (1080, "1080p"), (720, "720p"), (480, "480p")):
        if h >= lim:
            return f" ({lab})"
    return ""


def _channels(n):
    return {1: "مونو", 2: "ستيريو"}.get(n, f"{n} قنوات" if n else "—")


async def _ffprobe(path: Path):
    proc = await asyncio.create_subprocess_exec(
        "ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, _err = await asyncio.wait_for(proc.communicate(), timeout=60)
    if proc.returncode != 0:
        raise RuntimeError("ffprobe failed")
    return json.loads(out.decode("utf-8", "replace"))


def _probe_pdf(path: Path):
    import pikepdf
    info = {"ok": True, "lines": [], "extra": [], "pdf": {}}
    try:
        with pikepdf.open(str(path)) as pdf:
            n = len(pdf.pages)
            info["pdf"]["pages"] = n
            info["lines"].append(("📃 عدد الصفحات", str(n)))
            try:
                box = [float(x) for x in pdf.pages[0].mediabox]
                w, h = abs(box[2] - box[0]) / 72 * 25.4, abs(box[3] - box[1]) / 72 * 25.4
                size = f"{w:.0f}×{h:.0f} mm"
                for nm, (a, b) in {"A4": (210, 297), "A3": (297, 420), "A5": (148, 210), "Letter": (216, 279)}.items():
                    if (abs(w - a) < 4 and abs(h - b) < 4) or (abs(w - b) < 4 and abs(h - a) < 4):
                        size += f" ({nm})"
                        break
                info["lines"].append(("📐 مقاس الصفحة", size))
            except Exception:
                pass
            info["lines"].append(("🔖 إصدار PDF", str(pdf.pdf_version)))
            info["lines"].append(("🔒 مشفّر", "لا"))
            try:
                for k, v in (pdf.docinfo or {}).items():
                    info["extra"].append((str(k).lstrip("/"), str(v)[:120]))
            except Exception:
                pass
    except pikepdf.PasswordError:
        info["pdf"]["encrypted"] = True
        info["lines"].append(("🔒 مشفّر", "أيوه — محتاج كلمة سر"))
    except Exception as e:  # ملف تالف أو غير قياسي
        info["ok"] = False
        info["lines"].append(("⚠️ PDF", f"مقدرتش أقرأ بنيته ({type(e).__name__})"))
    return info


async def probe_file(path, kind: str, name: str = "", mime: str | None = None) -> dict:
    """بيرجّع {"ok", "lines": [(label, value)], "extra": [...], "duration", "width", "height", ...}"""
    path = Path(path)
    size = path.stat().st_size
    base = {"ok": True, "lines": [("📦 الحجم", f"{human_size(size)}")], "extra": [], "size": size}
    _s, ext = split_ext(name or path.name)
    if ext:
        base["lines"].append(("🧩 الامتداد", ext.lstrip(".").lower()))

    if kind == "pdf":
        try:
            r = await asyncio.to_thread(_probe_pdf, path)
        except ImportError:
            return {**base, "lines": base["lines"] + [("⚠️", "pikepdf مش متثبّت")]}
        base["lines"] += r["lines"]
        base["extra"] = r["extra"]
        base["pdf"] = r.get("pdf", {})
        return base

    if kind in ("audio", "video", "image"):
        try:
            d = await _ffprobe(path)
        except FileNotFoundError:
            base["lines"].append(("⚠️", "ffprobe مش موجود — شغّل bootstrap"))
            return base
        except Exception:
            base["lines"].append(("⚠️", "مقدرتش أحلل الملف (ممكن يكون تالف أو صيغة غريبة)"))
            base["ok"] = False
            return base

        fmt = d.get("format", {})
        streams = d.get("streams", [])
        a = next((s for s in streams if s.get("codec_type") == "audio"), None)
        v = next((s for s in streams if s.get("codec_type") == "video"
                  and not s.get("disposition", {}).get("attached_pic")), None)
        cover = any(s.get("disposition", {}).get("attached_pic") for s in streams)
        subs = [s for s in streams if s.get("codec_type") == "subtitle"]
        n_audio = sum(1 for s in streams if s.get("codec_type") == "audio")
        tags = {k.lower(): str(val) for k, val in (fmt.get("tags") or {}).items()}

        dur = fmt.get("duration")
        try:
            dur = float(dur) if dur not in (None, "N/A") else None
        except ValueError:
            dur = None
        base["duration"] = dur
        container = (fmt.get("format_name") or "").split(",")[0]
        if container == "mov" and ext in (".mp4", ".m4a", ".m4v"):
            container = "mp4"   # ffprobe بيسمّيها mov,mp4,m4a… والأولى بتضلل
        if container:
            base["lines"].append(("🎞 الحاوية", container))

        if kind in ("audio", "video") and dur:
            base["lines"].append(("⏱ المدة", human_duration(dur)))
        if fmt.get("bit_rate") not in (None, "N/A"):
            base["lines"].append(("🎚 Bitrate الكلي", human_bitrate(fmt["bit_rate"])))
            base["bitrate"] = int(fmt["bit_rate"])
        if v:
            h = v.get("height")
            base["width"], base["height"] = v.get("width"), h
            base["lines"].append(("📺 الأبعاد", f"{v.get('width')}×{h}{_res_label(h)}"))
            fps = _fps(v.get("avg_frame_rate") or v.get("r_frame_rate") or "")
            if fps and kind == "video":
                base["lines"].append(("🎬 FPS", str(fps)))
            base["lines"].append(("🧠 كودك الصورة", v.get("codec_name", "—")))
        if a:
            base["lines"].append(("🔊 كودك الصوت", a.get("codec_name", "—")))
            if a.get("sample_rate"):
                base["lines"].append(("📻 Sample rate", f"{int(a['sample_rate']) / 1000:g} kHz"))
            ch = a.get("channels")
            base["channels"] = ch
            base["lines"].append(("🔈 القنوات", _channels(ch)))
            if a.get("bit_rate") not in (None, "N/A") and kind == "audio":
                base["audio_bitrate"] = int(a["bit_rate"])
            if n_audio > 1:
                base["lines"].append(("🎧 مسارات صوت", str(n_audio)))
        if subs:
            base["lines"].append(("💬 ترجمات", str(len(subs))))
        if cover and kind == "audio":
            base["lines"].append(("🖼 غلاف", "موجود"))
        for key, label in (("title", "العنوان"), ("artist", "الفنان"), ("album", "الألبوم"), ("date", "التاريخ")):
            if tags.get(key):
                base["lines"].append((f"🏷 {label}", tags[key][:80]))
        base["title"], base["artist"] = tags.get("title"), tags.get("artist")
        base["extra"] = [(k, val[:120]) for k, val in tags.items()]
        base["extra"] += [(f"stream #{s.get('index')}", f"{s.get('codec_type')}/{s.get('codec_name')}") for s in streams]
        return base

    m = mime or mimetypes.guess_type(name or path.name)[0]
    if m:
        base["lines"].append(("🧪 النوع (MIME)", m))
    return base
