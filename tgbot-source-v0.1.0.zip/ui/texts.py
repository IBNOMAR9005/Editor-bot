"""كل النصوص (عربي، لهجة مصرية بسيطة). HTML parse mode — أي نص جاي من خارج بيتعمله esc()."""
from __future__ import annotations

from core import registry as R
from core.utils import esc, human_elapsed, human_size, mem_info, disk_free

BAR = "━━━━━━━━━━━━━━"


def _ready_lines(compact=False):
    seen, out = set(), []
    for a in R.ready_actions():
        if a.key in seen:
            continue
        seen.add(a.key)
        out.append(f"{a.label}" + (f" — {a.blurb}" if a.blurb and not compact else ""))
    return out


def _upcoming_by_phase():
    by = {}
    for a in R.upcoming_actions():
        by.setdefault(a.phase, []).append(a)
    return dict(sorted(by.items()))


def capabilities() -> str:
    lines = ["❓ <b>أنا أقدر أعمل إيه؟</b>", BAR, "✅ <b>شغّال دلوقتي</b>"]
    lines += [f"• {l}" for l in _ready_lines()]
    lines += ["", "🔜 <b>جاي في المراحل الجاية</b>"]
    for ph, acts in _upcoming_by_phase().items():
        names = " • ".join(dict.fromkeys(a.label for a in acts))
        lines.append(f"<b>المرحلة {ph} — {R.PHASES[ph]}:</b> {names}")
    lines += ["", BAR,
              "💡 <b>إزاي أستخدمني؟</b>",
              "• ابعت <b>أي ملف</b> وهطلعلك كارت ببياناته وأزرار تناسب نوعه.",
              "• أو دوس زرار من اللوحة اللي تحت، وبعدين ابعت الملف.",
              "• الحد الأقصى للملف: <b>2 GB</b> (سيرفر محلي).",
              "• الأوامر: /start /menu /id /cancel"]
    return "\n".join(lines)


def startup(info: dict) -> str:
    """رسالة 'البوت اشتغل': الحالة + أدواته + قدراته."""
    kind = info.get("boot_kind")
    head = {
        "recovered": "🔁 <b>رجعت للشغل</b> بعد انقطاع",
        "restart": "🔄 <b>اتعمل لي restart</b> وأنا شغّال تاني",
    }.get(kind, "✅ <b>البوت اشتغل</b>")
    lines = [f"{head} — <code>v{esc(info['version'])}</code>", BAR]

    if kind == "recovered":
        gap = info.get("gap_seconds")
        lines.append(f"⏱ كنت واقف حوالي <b>{human_elapsed(gap) if gap else 'فترة'}</b>.")
        lost = info.get("lost_jobs") or []
        if lost:
            lines.append("⚠️ المهام دي كانت شغّالة وضاعت، ابعت الملف تاني:")
            lines += [f"  • {esc(t)}" for t in lost[:5]]
        lines.append("📨 أي رسايل بعتّها وأنا واقف اتتجاهلت — ابعتها تاني.\n")

    srv = "✅ شغّال (حد الملفات 2GB)" if info.get("server_ok") else "❌ واقف"
    lines.append(f"🖥 السيرفر المحلي: {srv}")
    gpu = info.get("gpu")
    lines.append("⚡ GPU: " + ("✅ NVENC شغّال" if gpu == "nvenc" else "🟡 موجود بس NVENC مش متاح" if gpu == "gpu" else "— مفيش (CPU)"))
    lines.append(f"💾 الديسك: {human_size(info.get('disk_free'))} فاضية • 🧠 RAM: {human_size(info.get('mem_avail'))} متاحة")
    tools = info.get("tools") or {}
    if tools:
        lines.append("🧰 " + " • ".join(f"{'✅' if ok else '⚠️'} {n}" for n, ok in tools.items()))
    lines += ["", "🚀 <b>قدراتي دلوقتي:</b>"]
    lines += [f"• {l}" for l in _ready_lines(compact=True)]
    soon = _upcoming_by_phase()
    if soon:
        lines.append(f"\n🔜 جاي: " + " • ".join(f"{R.PHASES[p]}" for p in soon))
    lines += ["", "👇 اللوحة تحت جاهزة — ابعت ملف أو دوس زرار. (<b>❓ القدرات</b> للتفاصيل)"]
    return "\n".join(lines)


def welcome(name: str = "") -> str:
    hello = f"أهلًا {esc(name)} 👋" if name else "أهلًا 👋"
    return (f"{hello}\nأنا بوت الميديا الشخصي بتاعك: صوت • فيديو • PDF.\n\n"
            "ابعت <b>أي ملف</b> وهطلعلك كارت ببياناته وأزرار تناسبه، أو استخدم اللوحة تحت 👇")


def section_intro(section: str) -> str:
    title = R.SECTIONS.get(section, section)
    ready = [a for a in R.for_section(section) if a.ready]
    soon = [a for a in R.for_section(section) if not a.ready]
    lines = [f"<b>{title}</b>", BAR]
    if section in ("audio", "video", "pdf"):
        what = {"audio": "ملف صوت أو ريكورد", "video": "فيديو", "pdf": "ملف PDF"}[section]
        lines.append(f"📥 ابعت <b>{what}</b> دلوقتي وهتظهر لك أدواته.")
    if ready:
        lines += ["", "✅ <b>جاهز:</b>"] + [f"• {a.label} — {a.blurb}" for a in ready]
    if soon:
        ph = soon[0].phase
        lines += ["", f"🔜 <b>جاي في المرحلة {ph} ({R.PHASES[ph]}):</b>"]
        lines += [f"• {a.label}" + (f" — {a.blurb}" if a.blurb else "") for a in soon if a.label]
    lines += ["", "✏️ في الوقت ده تقدر تبعت أي ملف وتغيّر اسمه، وتشوف كل بياناته."]
    return "\n".join(lines)


def rename_intro() -> str:
    return ("✏️ <b>إعادة تسمية</b>\n" + BAR +
            "\n📥 ابعت <b>أي ملف</b> (صوت، فيديو، PDF، صورة، أرشيف…) وهفتحلك شاشة التسمية على طول.\n"
            "• بحافظ على الامتداد تلقائيًا (وتقدر تغيّره).\n• ملفات لحد 2GB من غير تنزيل/رفع زيادة.")


def link_intro() -> str:
    return ("⬇️ <b>التحميل من رابط (yt-dlp)</b>\n" + BAR +
            "\n🔜 الميزة دي جاية في <b>المرحلة 5</b>.\nهتبعت أي رابط، وتشوف الصيغ المتاحة (دقة/كودك/حجم) بأزرار وتختار صوت أو فيديو.\n\n"
            "💡 لحد ما تجهز: ابعت ملفات عادية وهتلاقي كل أدواتها الجاهزة.")


def meta_intro() -> str:
    return ("🏷️ <b>Metadata</b>\n" + BAR +
            "\n🔜 التعديل والحذف جايين في <b>المرحلة 6</b>.\n"
            "✅ دلوقتي: ابعت أي ملف وهتشوف كل بياناته في الكارت، ولو دوست <b>📋 كل التفاصيل</b> هتشوف الـ tags كاملة.")


def status(info: dict) -> str:
    q = info.get("queue", {})
    lines = ["📊 <b>حالة النظام</b>", BAR,
             f"🤖 الإصدار: <code>v{esc(info['version'])}</code> • ⏱ شغّال من {human_elapsed(info['uptime'])}",
             f"🖥 السيرفر المحلي: {'✅ شغّال' if info.get('server_ok') else '❌ واقف'}",
             f"📋 الطابور: " + (f"شغّال «{esc(q['running'])}»" if q.get("running") else "فاضي") +
             (f" • منتظر {q['waiting']}" if q.get("waiting") else ""),
             f"💾 الديسك: {human_size(info.get('disk_free'))} فاضية",
             f"🧠 RAM: {human_size(info.get('mem_avail'))} / {human_size(info.get('mem_total'))}"]
    gpu = info.get("gpu")
    lines.append("⚡ GPU: " + ("✅ NVENC" if gpu == "nvenc" else "🟡 موجود بدون NVENC" if gpu == "gpu" else "مفيش"))
    tools = info.get("tools") or {}
    if tools:
        lines.append("🧰 " + " • ".join(f"{'✅' if ok else '⚠️'} {n}" for n, ok in tools.items()))
    return "\n".join(lines)


def file_card(kind: str, name: str, lines, hints, upcoming_names, note: str = "") -> str:
    out = [f"{R.KINDS_LABEL.get(kind, '📎 ملف')}", f"<code>{esc(name)}</code>", ""]
    out += [f"{l}: {esc(v)}" for l, v in lines]
    if hints:
        out += [""] + hints
    if note:
        out += ["", note]
    if upcoming_names:
        out += ["", f"🔜 <i>جاي لنوع الملف ده: {esc(' • '.join(upcoming_names))}</i>"]
    return "\n".join(out)


def file_details(name: str, lines, extra) -> str:
    out = ["📋 <b>كل التفاصيل</b>", f"<code>{esc(name)}</code>", ""]
    out += [f"{l}: {esc(v)}" for l, v in lines]
    if extra:
        out += ["", "<b>Tags / Streams:</b>"] + [f"• {esc(k)}: {esc(v)}" for k, v in extra[:25]]
    text = "\n".join(out)
    return text[:3900]


def rename_prompt(name: str, final_hint: str, ext_mode: str, orig_ext: str) -> str:
    ext_line = ""
    if orig_ext:
        ext_line = (f"🔤 الامتداد <code>{esc(orig_ext)}</code> هيتحافظ عليه تلقائيًا." if ext_mode == "keep"
                    else "🔤 اكتب الاسم <b>كامل بامتداده</b> (مثلًا <code>اسم.mp3</code>).")
    return ("✏️ <b>إعادة تسمية</b>\n"
            f"الاسم الحالي:\n<code>{esc(name)}</code>\n\n"
            "✍️ <b>اكتب الاسم الجديد</b> وابعته" + (" أو اختار الاسم الذكي 👇" if final_hint else "") + f"\n{ext_line}\n"
            "<i>⏳ عندك 5 دقايق.</i>")
