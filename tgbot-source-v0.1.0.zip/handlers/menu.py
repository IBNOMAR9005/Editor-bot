"""الأزرار الرئيسية: كل زرار بيفتح لوحة قسمه ويظبط "النية" (intent) لو هتبعت ملف بعده."""
from __future__ import annotations

from aiogram import F, Router
from aiogram.types import Message

from handlers.common import safe_delete
from ui import keyboards as K, texts as T

router = Router(name="menu")


async def _open(msg: Message, ctx, section: str, text: str, intent: str | None = None):
    uid = msg.from_user.id
    ctx.dialogs.clear(uid)
    ctx.dialogs.section[uid] = section
    if intent:
        ctx.dialogs.set_intent(uid, intent)
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    await msg.answer(text, reply_markup=K.section_panel(section))


@router.message(F.text == K.M_AUDIO)
async def audio(msg: Message, ctx):
    await _open(msg, ctx, "audio", T.section_intro("audio"))


@router.message(F.text == K.M_VIDEO)
async def video(msg: Message, ctx):
    await _open(msg, ctx, "video", T.section_intro("video"))


@router.message(F.text == K.M_PDF)
async def pdf(msg: Message, ctx):
    await _open(msg, ctx, "pdf", T.section_intro("pdf"))


@router.message(F.text == K.M_RENAME)
async def rename(msg: Message, ctx):
    await _open(msg, ctx, "general", T.rename_intro(), intent="rename")


@router.message(F.text == K.M_DL)
async def link(msg: Message, ctx):
    await _open(msg, ctx, "link", T.link_intro())


@router.message(F.text == K.M_META)
async def meta(msg: Message, ctx):
    await _open(msg, ctx, "meta", T.meta_intro())
