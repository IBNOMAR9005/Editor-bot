from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from core.progress import edit_safe
from handlers.common import safe_delete
from ui import keyboards as K, texts as T

router = Router(name="start")


@router.message(Command("id"))
async def cmd_id(msg: Message):
    # شغّال حتى لغير المصرّح لهم (الـ middleware بيسمح بيه بس): بيرجّع الرقم من غير أي وظيفة تانية
    await msg.answer(f"🆔 رقم حسابك: <code>{msg.from_user.id}</code>")


@router.message(CommandStart())
@router.message(Command("menu"))
async def cmd_start(msg: Message, ctx):
    ctx.dialogs.clear(msg.from_user.id)
    await msg.answer(T.welcome(msg.from_user.first_name), reply_markup=K.main_keyboard())


@router.message(Command("cancel"))
async def cmd_cancel(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    dlg = ctx.dialogs.get(uid)
    jobs = ctx.queue.user_jobs(uid)
    ctx.dialogs.clear(uid)
    for j in jobs:
        ctx.queue.cancel(j.id, uid)
    if dlg:
        await edit_safe(bot, dlg.chat_id, dlg.msg_id, "✖️ اتلغت العملية.", None)
    await msg.answer("🛑 اتلغى كل حاجة شغّالة." if (dlg or jobs) else "مفيش حاجة شغّالة أوقفها 👌",
                     reply_markup=K.main_keyboard())


@router.message(Command("help"))
@router.message(F.text == K.M_HELP)
async def show_help(msg: Message, ctx):
    ctx.dialogs.clear(msg.from_user.id)
    if ctx.store.get_setting(msg.from_user.id, "clean_chat"):
        await safe_delete(msg)
    await msg.answer(T.capabilities(), reply_markup=K.help_panel())


@router.message(F.text == K.M_STATUS)
async def show_status(msg: Message, ctx):
    ctx.dialogs.clear(msg.from_user.id)
    if ctx.store.get_setting(msg.from_user.id, "clean_chat"):
        await safe_delete(msg)
    await msg.answer(T.status(ctx.sysinfo()), reply_markup=K.status_panel())


@router.callback_query(F.data == "m:help")
async def cb_help(cb: CallbackQuery, bot: Bot):
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, T.capabilities(), K.help_panel())
    await cb.answer()


@router.callback_query(F.data == "m:status")
async def cb_status(cb: CallbackQuery, bot: Bot, ctx):
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, T.status(ctx.sysinfo()), K.status_panel())
    await cb.answer("اتحدّث ✅")


@router.callback_query(F.data == "x:close")
async def cb_close(cb: CallbackQuery):
    await safe_delete(cb.message)
    await cb.answer()
