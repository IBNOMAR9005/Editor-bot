"""آخر router: أي نص مفيش حد مسؤول عنه (لازم يتسجّل أخيرًا)."""
from __future__ import annotations

import re

from aiogram import F, Router
from aiogram.types import Message

from ui import keyboards as K, texts as T

router = Router(name="fallback")
URL_RE = re.compile(r"https?://\S+", re.I)


@router.message(F.text.startswith("/"))
async def unknown_command(msg: Message):
    await msg.answer("🤔 الأمر ده مش عندي. المتاح: /start /menu /id /cancel /help", reply_markup=K.main_keyboard())


@router.message(F.text)
async def on_text(msg: Message):
    if URL_RE.search(msg.text):
        return await msg.answer(T.link_intro(), reply_markup=K.section_panel("link"))
    await msg.answer("📎 ابعت <b>ملف</b> وأنا أطلعلك أدواته، أو اختار من اللوحة تحت 👇", reply_markup=K.main_keyboard())
