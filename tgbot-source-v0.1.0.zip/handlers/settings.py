from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, Message

from core.progress import edit_safe
from handlers.common import safe_delete
from ui import keyboards as K

router = Router(name="settings")
TITLE = "⚙️ <b>الإعدادات</b>\nدوس على أي خيار عشان تبدّله (✅ شغّال / ⬜ مقفول). بتتحفظ تلقائيًا."


@router.message(F.text == K.M_SETTINGS)
async def open_settings(msg: Message, ctx):
    uid = msg.from_user.id
    ctx.dialogs.clear(uid)
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    await msg.answer(TITLE, reply_markup=K.settings_panel(ctx.store.all_settings(uid)))


@router.callback_query(F.data == "m:settings")
async def cb_open(cb: CallbackQuery, bot: Bot, ctx):
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, TITLE,
                    K.settings_panel(ctx.store.all_settings(cb.from_user.id)))
    await cb.answer()


@router.callback_query(F.data.startswith("s:tgl:"))
async def toggle(cb: CallbackQuery, bot: Bot, ctx):
    key = cb.data.split(":", 2)[2]
    if key not in K.SETTING_LABELS:
        return await cb.answer()
    uid = cb.from_user.id
    ctx.store.set_setting(uid, key, not ctx.store.get_setting(uid, key))
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, TITLE, K.settings_panel(ctx.store.all_settings(uid)))
    await cb.answer("اتحفظ ✅")
